package com.example.the_anime_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
